<?php
$waf_allow_list = array (
);
return $waf->is_ip_in_array( $waf_allow_list );
