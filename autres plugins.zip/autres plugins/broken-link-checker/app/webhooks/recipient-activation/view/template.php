<?php
/**
 * The template for displaying the response of broken link checker recipient activation event.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Broken_Link_Checker
 * @since Twenty Twenty-One 1.0
 */

get_header( 'home' );



get_footer();
