<?php return array('dependencies' => array('wc-settings', 'wc-tracks', 'wp-hooks'), 'version' => '2e53703446ae7e6d3e3d');
